<?php

 $con = mysqli_connect("localhost" , "root" , "" , "nextlevel");
if (!$con){
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
$query = "SELECT * FROM `products` ";
 $result = mysqli_query( $con , $query);
// if (mysqli_num_rows($result) > 0) {
//     // output data of each row
//     while($row = mysqli_fetch_assoc($result)) {
//         echo " " . $row["ID"]. " " . $row["Name"]. " " . $row["Category"].$row["Price"] ;

//     }
// } else {
//     echo "0 results";
// }


 if (mysqli_num_rows($result) > 0) {
        echo '<table border="1px">';
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Name (INR)</th>";
        echo "<th>Category</th>";
        echo "<th>Price</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['ID'] . "</td>";
            echo "<td>" . $row['Name'] . "</td>";
            echo "<td>" . $row['Category'] . "</td>";
            echo "<td>" . $row['Price'] ."</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else {
        echo "No records found";
    }

?>
